THIS DRIVER IS STILL IN BETA TESTING, but it is believed to be
very stable.

The driver will work with Windows 9X, NT, and 2000

The directions on how to install the driver and what valid command
calls you can make to the driver can be found in the file Bird.h and 
the Windows Dirver Users Manual.  There is an example prgam at the 
end of the manual that demonstrates the driver's use.

The driver will work with all Ascension ISA, RS232, TCP/IP products.
