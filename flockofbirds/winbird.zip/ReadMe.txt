winBIRD is a Windows based program which allows the user to access the full functionality of Ascension products.

To install winBIRD:
If winBIRD is being installed on a Windows 2000 machine, or on a machine that already has Windows Installer, 
only the winBIRD.msi file is needed. This can greatly reduce the download time. Double clicking the winBIRD.msi file
will start the installation. The computer will need to be restarted before winBIRD will run.

If your machine doesn't have Windows Installer, or if you don't know if you have Windows Installer, more files are
needed. InstMsiA.exe, InstMsi.exe, setup.ini, setup.exe, and winBIRD.msi will all be needed. Double clicking the
setup.exe file will start the installation process. It may be necessary to restart your computer twice. The first
restart will load the Windows Installer, the second restart will load winBIRD.

The installation process will create a shortcut at Start->Programs->Ascension Technology->winBIRD. Clicking this 
shortcut or the executable file will start the program. If the program does not appear after clicking the shortcut or
the executable, it may be beacuse the computer was not restarted after the installation.

Once winBIRD is installed and running, help files are available under Help->Help Topics.