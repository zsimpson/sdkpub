/*
 *  testkey.cpp
 *  
 *
 *  Created by Thomas Blom on 4/20/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */


#include "time.h"
#include "sys/time.h"
#include "unistd.h"
#include "stdlib.h"
#include "stdio.h"

extern "C" {
#include "UniKey.h"
}

double getTimeSecs() {
	struct timeval tv;
	struct timezone tz;
	gettimeofday( &tv, &tz );
	
	int _mils = tv.tv_usec/1000;
	int _secs = tv.tv_sec;
	
	return (double)_secs + (double)_mils/1000.0;
}

int usbKeyCheck() {
	
	#define MemorySize 4096
	WORD handle, p1, p2, p3, p4;
	DWORD lp1, lp2;
	static BYTE buffer[MemorySize];
	unsigned long i;
	unsigned long numDevices = 0;
	unsigned long chipIdList[128];
	
	p1 = 1234;	// passwords: set these to match your key
	p3 = 1234;
	p2 = 1234;
	p4 = 1234;
	
	// find dongle
	long retcode = UniKey(UNIKEY_FIND, &handle, &lp1, &lp2, &p1, &p2, &p3, &p4, buffer);
	if (retcode) {
		// no dongle attached!
		return 0;
	}
	chipIdList[ numDevices++ ] = lp1;
	
	for( i=0; !retcode && i<127; i++ ) {
		retcode = UniKey(UNIKEY_FIND_NEXT, &handle, &lp1, &lp2, &p1, &p2, &p3, &p4, buffer);
		if (!retcode) {
			chipIdList[ numDevices++ ] = lp1;
		}
	}
	
	int foundKey=0;
	for( i=0; !foundKey && i<numDevices; i++ ) {
		lp1 = chipIdList[ i ];
		retcode = UniKey( UNIKEY_LOGON, &handle, &lp1, &lp2, &p1, &p2, &p3, &p4, buffer );
		if( retcode == 0 ) {
			foundKey = 1;
		}
	}
	return foundKey;
}

int main() {

	// This program tries to find a key that is stampede with our password and logon to it.
	// To check the timing of this operation, we perform it ten times.
	
	double timeBegin = getTimeSecs();
	
	int successCount = 0;
	for( int i=0; i<10; i++ ) {
		successCount += usbKeyCheck();
	}
	
	double timeEnd = getTimeSecs();
	
	printf( "Checking the key 10 times took %g seconds, and was successful %d times.\n", timeEnd-timeBegin, successCount );
		
	return 0;
}
				


